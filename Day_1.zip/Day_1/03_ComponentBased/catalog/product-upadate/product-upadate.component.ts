import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-upadate',
  templateUrl: './product-upadate.component.html',
  styleUrls: ['./product-upadate.component.css']
})
export class ProductUpadateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
