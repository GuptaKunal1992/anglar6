import { Component, OnInit } from '@angular/core';
import { ProductService } from '../productservice';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
  providers:[ProductService]
})
export class ProductListComponent implements OnInit {

  //flowers=["Rose","Louts", "Lily", "Marigold","Jasmine"];
  flowers=[];

    
  constructor(private svc:ProductService) {

    console.log("Product List instance created constructor");
   }

  ngOnInit() {
    this.flowers= this.svc.getProducts();
  }

}
