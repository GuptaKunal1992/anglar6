import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-insert',
  templateUrl: './product-insert.component.html',
  styleUrls: ['./product-insert.component.css']
})
export class ProductInsertComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
