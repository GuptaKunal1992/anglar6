import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { CatalogModule } from '../../projects/catalog/src/public_api';
import { CrmModule } from '../../projects/crm/src/public_api';
import { ShoppingcartModule } from '../../projects/shoppingcart/src/public_api';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,CatalogModule,CrmModule,ShoppingcartModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
