/*
 * Public API Surface of crm
 */

export * from './lib/crm.service';
export * from './lib/crm.component';
export * from './lib/crm.module';
