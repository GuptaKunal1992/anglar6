import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cart-shoppingcart',
  template: `
    <p>
      shoppingcart works!
    </p>

    <h2>Cart Items</h2>
    <ol>
    <li>Gerbera :20</li>
    <li>Lotus :5</li>
    <li>Marigold :30</li>
    </ol>

  `,
  styles: []
})
export class ShoppingcartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
