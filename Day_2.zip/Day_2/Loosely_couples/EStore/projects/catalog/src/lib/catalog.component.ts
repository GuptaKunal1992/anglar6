import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cat-catalog',
  template: `
    <p>catalog works!</p>
    <h2>Product List</h2>
    <ol>
    <li>Gerbera </li>
    <li>Lotus </li>
    <li>Marigold </li>
    <li>Lily </li>
    <li>Jasmine </li>
    </ol>
  `,
  styles: []
})
export class CatalogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
