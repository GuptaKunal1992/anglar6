import { Component, ViewChild, ViewContainerRef, 
         ComponentFactoryResolver} from '@angular/core';
import { MessageComponent } from './message/message.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Dynamic';
  componentRef: any;

  @ViewChild('messagecontainer', 
             { read: ViewContainerRef }) container: ViewContainerRef;
  constructor(private resolver: ComponentFactoryResolver) { }

  createComponent(message) {
    this.container.clear();
    const factory = this.resolver.resolveComponentFactory(MessageComponent);
    this.componentRef = this.container.createComponent(factory);
    this.componentRef.instance.message = message;
  }

  destroyComponent() {
    this.componentRef.destroy();
  }
}