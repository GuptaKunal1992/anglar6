"use strict";
var shape_1 = require('./shape');
var l = new shape_1.Drawing.Line();
var rect = new shape_1.Drawing.Rectangle();
var s = l;
s.draw("2D");
console.log('Line');
//# sourceMappingURL=test.js.map