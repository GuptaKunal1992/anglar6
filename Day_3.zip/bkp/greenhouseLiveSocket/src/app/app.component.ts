import { Component, OnInit, OnDestroy } from '@angular/core';

import { Subscription } from 'rxjs/Subscription';
import { HumidityService } from './core/humidity.service';
import { TemperatureService } from './core/temp.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit, OnDestroy {

  temp: number;
  humidity:number;
  windspeed:number=45;
  moisture:number=4000;
  ph:number=6.5;
  subHumidity : Subscription;
  subTemp: Subscription;

  constructor(private svcTemp: TemperatureService,private svcHumidity:HumidityService,) { }

  ngOnInit() {
    this.subTemp = this.svcTemp.getTemp()
        .subscribe(data => { this.temp = data;});

    this.subHumidity = this.svcHumidity.getHumidity()
    .subscribe(temp => { this.humidity = temp;});
  }

  ngOnDestroy() {
    this.subTemp.unsubscribe();
    this.subHumidity.unsubscribe();
  }
}
