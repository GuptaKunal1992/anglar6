import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HumidityService } from './humidity.service';
import { TemperatureService } from './temp.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [HumidityService,TemperatureService]
})
export class CoreModule { }
