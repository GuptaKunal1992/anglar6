const express = require('express'),
      app = express(),
      server = require('http').createServer(app);
      io = require('socket.io')(server);

let timerTemp = null,
    timerhumidity=null,
    sockets = new Set();

app.use(express.static(__dirname + '/dist')); 

io.on('connection', socket => {

  sockets.add(socket);
  console.log(`Socket ${socket.id} added`);

  if (!timerTemp ) {
    startTimer();
  }

  socket.on('clientdata', data => {
    console.log(data);
  });

  socket.on('disconnect', () => {
    console.log(`Deleting socket: ${socket.id}`);
    sockets.delete(socket);
    console.log(`Remaining sockets: ${sockets.size}`);
  });

});

function startTimer() {
  //Simulate Greenhouse  data received by sensors that needs 
  //to be pushed to clients

  timerTemp = setInterval(() => {
    if (!sockets.size) {
      clearInterval(timerTemp);
      timerTemp = null;
      console.log(`Timer stopped`);
    }
    
    let temperature = ((Math.random() * 50) + 1).toFixed(2);
    for (const s of sockets) {
      console.log(`Emitting Temperature: ${temperature}`);
      s.emit('temp', { data: temperature });
    }
  }, 6000);


  timerhumidity = setInterval(() => {
    if (!sockets.size) {
      clearInterval(timerhumidity);
      timerhumidity = null;
      console.log(`Timer stopped`);
    }
    let humidty = ((Math.random() * 500) + 1).toFixed(2);
    for (const s of sockets) {
      console.log(`Emitting Humidity: ${humidty}`);
      s.emit('humidity', { data: humidty });
    }

  }, 2000);
}

server.listen(8080);
console.log('Visit http://localhost:8080 in your browser');