import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-fruits",
  templateUrl: "./fruits.component.html",
  styleUrls: ["./fruits.component.css"]
})
export class FruitsComponent implements OnInit {
  fruits = [];
 
  constructor() {}

  ngOnInit() {
        this.fruits = ["Apple", "Orange","Kiwi","Banana",
                     "Cherry","Guava"];
  }
}
