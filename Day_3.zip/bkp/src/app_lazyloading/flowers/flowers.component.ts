import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-flowers',
  templateUrl: './flowers.component.html',
  styleUrls: ['./flowers.component.css']
})
export class FlowerComponent implements OnInit {
  flowers = [];
 
  constructor() {}

  ngOnInit() {
        this.flowers = ["Gerbera", "Carnation","Lotus","Marigold",
                     "Lily"];
  }
}
