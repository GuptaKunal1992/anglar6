import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import {FlowerRoutingModule} from './flowers-routing.module';
import { FlowerComponent } from "./flowers.component";


@NgModule({
    imports:[
        CommonModule,
        FlowerRoutingModule
    ],
    declarations:[FlowerComponent]
})

export class FlowersModule{}