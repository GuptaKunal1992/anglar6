import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import {FlowerComponent} from './flowers.component';

const routes:Routes=[
    {path:'',component:FlowerComponent}
]

@NgModule({
    imports:[RouterModule.forChild(routes)],
    exports:[RouterModule]
})

export class FlowerRoutingModule{}