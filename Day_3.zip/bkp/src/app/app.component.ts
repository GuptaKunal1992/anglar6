import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'HelloAngular';
  name="Ravi Tambade";
  flower={
    id:34,
    title:"Gerbera",
    description:"Wedding Flower",
    quantity:4500,
    price:5
  }
  available:boolean;

  constructor(){
    
  }

}
