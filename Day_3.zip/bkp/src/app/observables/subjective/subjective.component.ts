import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, AsyncSubject, ReplaySubject } from 'rxjs';
@Component({
  selector: 'app-subjective',
  templateUrl: './subjective.component.html',
  styleUrls: ['./subjective.component.css']
})
export class SubjectiveComponent implements OnInit {

  subjectBhvr = new BehaviorSubject(13);
  subjectReply = new ReplaySubject(2, 100);
  subjectAsync = new  AsyncSubject();
  constructor() { }

  ngOnInit() { 
   this.demoSubjectBeheaviour();
   //this.demoSubjectReplay();
   //this.demoAsynSubject();
  }


  demoSubjectBeheaviour(){

    // subscriber 1
    this.subjectBhvr.subscribe((data) => {
      console.log('Subscriber A Recived :', data);
    });

    this.subjectBhvr.next(Math.random());
    this.subjectBhvr.next(Math.random());

    // subscriber 2
    this.subjectBhvr.subscribe((data) => {
      console.log('Subscriber B Received:', data);
    });

    this.subjectBhvr.next(Math.random());

    console.log(this.subjectBhvr.value);

  }

  demoSubjectReplay(){
   // subscriber 1
    this.subjectReply.subscribe((data) => {console.log('Subscriber A:', data);});

    setInterval(() => this.subjectReply.next(Math.random()), 200);

    // subscriber 2
    setTimeout(() => {
      this.subjectReply.subscribe((data) => {console.log('Subscriber B Received:', data);});
    },1000)

}
  
  demoAsynSubject(){

    // subscriber 1
    this.subjectAsync.subscribe((data) => {
        console.log('Subscriber A Received :', data);
    });

    this.subjectAsync.next(Math.random())
    this.subjectAsync.next(Math.random())
    this.subjectAsync.next(Math.random())

    // subscriber 2
    this.subjectAsync.subscribe((data) => {
        console.log('Subscriber B Received:', data);
    });

    this.subjectAsync.next(Math.random());
    this.subjectAsync.complete();
  }
}
