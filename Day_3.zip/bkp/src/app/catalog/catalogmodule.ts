import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule   } from "@angular/forms";
import { ProductDetailComponent } from "./product-detail/product-detail.component";
import { ProductListComponent } from "./product-list/product-list.component";
import { ProductUpadateComponent } from "./product-upadate/product-upadate.component";
import { ProductInsertComponent } from "./product-insert/product-insert.component";
import { CounterComponent } from "./counter/counter.component";
import { ProductService } from "./productservice";
import { CustomModule } from "../custom/custommodule";
import { FlowerComponent, LifeCycleComponent } from "./lifecycle";
 

@NgModule({
    declarations: [
        CounterComponent,
        ProductDetailComponent,
        ProductListComponent,
        ProductUpadateComponent,
        ProductInsertComponent,
        FlowerComponent,
        LifeCycleComponent
    ],
    exports: [
        ProductDetailComponent,
        ProductListComponent,
        ProductUpadateComponent,
        ProductInsertComponent,
        LifeCycleComponent
       
    ],
    imports:[
        BrowserModule,
        FormsModule,
        CustomModule
    ],

    providers:[ ],
})
export class CatalogModule{}