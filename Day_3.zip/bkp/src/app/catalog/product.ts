
export class Product{

    constructor(private title:string,
                private description:string,
                private price:number,
                private quantity:number,
                private imageUrl:string,
                private likes:number){ }
}