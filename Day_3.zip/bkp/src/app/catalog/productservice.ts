import { Injectable } from "@angular/core";


@Injectable()
export class ProductService{
    private  myFlowers=[
    {name:"Rose", description:"Valentine Flower",price:45,likes:1400,quantity:15000 },
    {name:"Lotus", description:"Worship Flower",price:4,likes:300,quantity:70 },
    {name:"Lily", description:"Best Flower",price:145,likes:400, quantity:98 },
    {name:"Jasmine", description:"Smelling Flower",price:12,likes:400, quantity:236 },
    {name:"Carnation", description:"Festival Flower",price:45,likes:400, quantity:765 },
 ];

 constructor(){
     console.log(" Service constructor is invoked !");


 }
 public getProducts():any{
     return this.myFlowers;
 }
}