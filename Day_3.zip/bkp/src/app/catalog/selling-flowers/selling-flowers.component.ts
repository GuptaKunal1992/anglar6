import { Component, OnInit } from '@angular/core';


export const FLOWERS =  [
    {name: 'Gerbera', quantity:45, canSell: false},  //jSON Object
    {name: 'Carnation',quantity:65,  canSell: false},
    {name: 'Tulip',quantity:77,   canSell: false},
    {name: 'Marigold',quantity:108,   canSell: false},
    {name: 'Lily',quantity:176,   canSell: true},
    {name: 'Jasmine', quantity:99,  canSell: true}
  ];
  

  
@Component({
  selector: 'selling-flowers',
  templateUrl: './selling-flowers.component.html',
  styleUrls: ['./selling-flowers.component.css']
})
export class SellingFlowersComponent implements OnInit {

  flowers: any[] = [];
  constructor() { this.reset(); }

  ngOnInit() { }
  reset() { this.flowers = FLOWERS.slice(); }
}
