import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellingFlowersComponent } from './selling-flowers.component';

describe('SellingFlowersComponent', () => {
  let component: SellingFlowersComponent;
  let fixture: ComponentFixture<SellingFlowersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellingFlowersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellingFlowersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
