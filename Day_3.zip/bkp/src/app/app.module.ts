import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { CatalogModule } from './catalog/catalogmodule';
import { TemplateFormsModule } from './forms/templateforms.module';
import { ReactiveModule } from './reactive/reactive.module';
import { GraphicsModule } from './graphics/graphics.module';
import { SharedModule } from './shared/sharedmodule';
import { BIModule } from './BI/bi.module';
import { ObservableModule } from './observables/observable.module';
import { CustomModule } from './custom/custommodule';
import { SellingFlowersComponent } from './catalog/selling-flowers/selling-flowers.component';
import { SPAModule } from './routing/spa.module';
import { GitHttpModule } from './HTTP/githttp.module';
import { HDIModule } from './HDI/hdi.module';

/* Root Module for Application */
@NgModule({
  declarations: [AppComponent, SellingFlowersComponent],
  imports: [
    BrowserModule,
    CatalogModule,
    SharedModule,
    CustomModule,
    GraphicsModule,
    BIModule,
    TemplateFormsModule,
    ReactiveModule,
    ObservableModule,
    SPAModule,
    GitHttpModule,
    HDIModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
