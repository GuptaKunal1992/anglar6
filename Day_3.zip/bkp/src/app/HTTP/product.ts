
  export class Product{
    constructor(
        public productID:number,
        public title:string,
        public description:string,
        public price:number,
        public quantity:number,
        public category:string,
        public paymentTerm:string,
        public delivery:string
    ){ }
  }
