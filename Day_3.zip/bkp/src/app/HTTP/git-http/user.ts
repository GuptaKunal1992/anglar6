
export class User  {  
    constructor(public name:string,
                public location:string,
                public company:string,
                public blog:string)  { }
    } 