import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

//import { PageNotFoundComponent } from "./page-not-found.component";
import { CustomPreloadingStrategy } from "./custom-preloading-strategy";
import { FlowerComponent } from "./flowers/flowers.component";
import { HomeComponent } from "./home/home.component";

const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "fruits", loadChildren: "../app/fruits/fruits.module#FruitsModule",data: { preload: true } },
  { path: "flowers", loadChildren: "../app/flowers/flowers.module#FlowersModule",data: { preload: true }},
  { path: "vegetables", loadChildren: "../app/vegetables/vegetables.module#VegetablesModule"},
 // {path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [ 
    RouterModule.forRoot(routes,
                         {preloadingStrategy: CustomPreloadingStrategy}) 
],
exports: [ RouterModule ],
providers: [ CustomPreloadingStrategy ]
})
export class AppRoutingModule {}