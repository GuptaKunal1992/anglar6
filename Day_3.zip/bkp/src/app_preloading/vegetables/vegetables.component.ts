import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-vegetables',
  templateUrl: './vegetables.component.html',
  styleUrls: ['./vegetables.component.css']
})
export class VegetablesComponent implements OnInit {
  vegetables = [];
 
  constructor() {}

  ngOnInit() {
        this.vegetables = ["Tomato","Carrot", "Broccoli","Beans","Celery",
                            "Spinach","Lettuce","Onion","Ginger"];
  }
}
