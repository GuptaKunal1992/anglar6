import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import {VegetablesRoutingModule} from './vegetables-routing.module';
import { VegetablesComponent } from "./vegetables.component";


@NgModule({
    imports:[
        CommonModule,
        VegetablesRoutingModule
    ],
    declarations:[VegetablesComponent]
})

export class VegetablesModule{}