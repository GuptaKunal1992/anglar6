import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'crm-crm',
  template: `
    <p>crm works!</p>

    <h2>Customers</h2>
    <ol>
    <li>IBM</li>
    <li>HCL</li>
    <li>Mastercard</li>
    </ol>
  `,
  styles: []
})
export class CrmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
