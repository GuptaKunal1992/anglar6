import { NgModule } from '@angular/core';
import { CrmComponent } from './crm.component';

@NgModule({
  imports: [
  ],
  declarations: [CrmComponent],
  exports: [CrmComponent]
})
export class CrmModule { }
