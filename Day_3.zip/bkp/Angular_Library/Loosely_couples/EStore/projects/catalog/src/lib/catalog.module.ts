import { NgModule } from '@angular/core';
import { CatalogComponent } from './catalog.component';

@NgModule({
  imports: [
  ],
  declarations: [CatalogComponent],
  exports: [CatalogComponent]
})
export class CatalogModule { }
