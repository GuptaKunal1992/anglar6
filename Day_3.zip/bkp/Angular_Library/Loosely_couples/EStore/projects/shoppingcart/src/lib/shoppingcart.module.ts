import { NgModule } from '@angular/core';
import { ShoppingcartComponent } from './shoppingcart.component';

@NgModule({
  imports: [
  ],
  declarations: [ShoppingcartComponent],
  exports: [ShoppingcartComponent]
})
export class ShoppingcartModule { }
