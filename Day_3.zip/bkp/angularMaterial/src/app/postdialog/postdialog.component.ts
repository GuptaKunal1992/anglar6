import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-postdialog',
  templateUrl: './postdialog.component.html',
  styleUrls: ['./postdialog.component.css']
})
export class PostdialogComponent implements OnInit {
 
  categories=[{viewValue:"Angular", value:"A"},
               {viewValue: "ReactJS",value:"R"},
               {viewValue:"VueJS",value:"V"}];
  blogPost = {
    title: 'What new in Front End',
    body: 'Lets us explore Front End Application Developement',
    category: 'Angular',
    position: 0,
    date_posted: new Date()
  };
  public event: EventEmitter<any> = new EventEmitter();

  constructor(  ) {
  }

  ngOnInit(): void {
    //throw new Error("Method not implemented.");
  }

  onNoClick(): void {
   
  }

  onSubmit(): void {
    console.log("Form is submitted");

  }

 

}
