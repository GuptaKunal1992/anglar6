import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { MatButtonModule,MatFormFieldModule,MatInputModule, MatToolbarModule,
         MatDialogModule, MatSelectModule, MatCardModule, MatListModule, MatIconModule, MatSidenavModule, MatGridListModule, MatMenuModule, MatTableModule, MatPaginatorModule, MatSortModule
} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { AppComponent } from './app.component';
import { PostdialogComponent } from './postdialog/postdialog.component';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { LayoutModule } from '@angular/cdk/layout';
import { RouterModule, Routes } from '@angular/router';
import { CustomersComponent } from './customers/customers.component';
import { MyNavComponent } from './my-nav/my-nav.component';
import { MyDashboardComponent } from './my-dashboard/my-dashboard.component';
import { NameComponent } from './name/name.component';

const appRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  {path:'dashboard',component:MyDashboardComponent},
  { path: 'posts', component: PostdialogComponent },
  { path: 'customers', component: CustomersComponent }
  
];

@NgModule({
  declarations: [
    AppComponent,
    PostdialogComponent,
    HomeComponent,
    CustomersComponent,
    MyNavComponent,
    MyDashboardComponent,
    NameComponent
  ],
  imports: [
    BrowserModule,BrowserAnimationsModule,
    MatButtonModule, MatFormFieldModule,MatInputModule,MatToolbarModule,
    MatDialogModule, MatSelectModule,
    BrowserAnimationsModule,
    LayoutModule,
    RouterModule.forRoot(appRoutes),
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatCardModule,
    FormsModule,
    MatGridListModule,
    MatMenuModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
