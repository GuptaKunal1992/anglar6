const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

app.use(express.static(__dirname));
app.use(bodyParser.json()); 

var flowers = [
  { "id": 1, "name": "Gerbera" },
  { "id": 2, "name": "Rose" },
  { "id": 3, "name": "Louts" }
];

var fruits = [
  { "title": "Mango" },
  { "title": "Grapes" },
  { "title": "Banana" }
];

var vegetables = [
  { "title": "Tomatto" },
  { "title": "Potato" },
  { "title": "Capsicum" }
];

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname,'/dist/index.html'))
});

app.get('/api/fruits', function (req, res) {
    res.send(fruits);
});


app.get('/api/vegetables', function (req, res) {
    res.send(vegetables);
});


app.get('/api/flowers', function (req, res) {
    console.log("GET Flowers");
    res.send(flowers);
});


app.post('/api/flowers', function (req, res) {
    console.log("POST flower: " + req.body.name);
    let id = 1;
    if (flowers.length > 0) {
        let maximum = Math.max.apply(Math, flowers.map(function (f) { return f.id; }));
        id = maximum + 1;
    }

    let new_flower = {"id": id, "name": req.body.name};
    flowers.push(new_flower);
    res.send(new_flower);
});

app.put('/api/flowers/:id', function (req, res) {
    console.log("PUT flower: " + req.params.id);
    let id = req.params.id;
    let f = flowers.find(x => x.id == id);
    f.name = req.body.name;
    res.send(f);
});

// DELETE endpoint for deleting food
app.delete('/api/flowers/:id', function (req, res) {
    console.log("DELETE flower: " + req.params.id);
    let id = req.params.id;
    let f = flowers.find(x => x.id == id);
    flowers = flowers.filter(x => x.id != id);
    res.send(f);
});

// catch 404 and forward to error handler
app.use(function(req, res, next) {
    let err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// HTTP listener
app.listen(3000, function () {
    console.log('Example listening on port 3000!');
});
module.exports = app;
