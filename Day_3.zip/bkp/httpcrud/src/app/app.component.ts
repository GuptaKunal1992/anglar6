import {Component} from '@angular/core';
import {TransflowerService} from './transflowerservice';
import {Observable} from 'rxjs/Rx';

@Component({
  selector: 'transflower-store',
  template:`
  <h1>Transflower Store</h1>
  <h2>Flowers</h2>
  <ul>
    <li *ngFor="let flower of flowers"><input type="text" name="flower-name" [(ngModel)]="flower.name"><button (click)="updateFlower(flower)">Save</button> <button (click)="deleteFlower(flower)">Delete</button></li>
  </ul>
  <p>Create a new Flower: <input type="text" name="flower_name" [(ngModel)]="flower_name"><button (click)="createFlower(flower_name)">Save</button></p>
  
  <h2>Fruits and Vegetables</h2>
  
  <p>data from multiple endpoints using Observable.forkJoin()</p>
  
  <h3>Fruits</h3>
  <ul>
    <li *ngFor="let fruit of fruits">{{fruit.title}}</li>
  </ul>
  <h3>Vegetables</h3>
  <ul>
    <li *ngFor="let vegetable of vegetables">{{vegetable.title}}</li>
  </ul>
  `
})
export class AppComponent {

  public flowers;
  public fruits;
  public vegetables;

  public flower_name;

  constructor(private svc: TransflowerService) { }

  ngOnInit() {
    this.getFlowers();
    this.getFruitsAndVegetables();
  }

  getFlowers() {
    this.svc.getFlowers().subscribe(
      data => { this.flowers = data},
      err => console.error(err),
      () => console.log('done loading flowers')
    );
  }

  getFruitsAndVegetables() {
    this.svc.getFruitsAndVegetables().subscribe(
      data => {
        this.fruits = data[0]
        this.vegetables = data[1]
      }
    );
  }

  createFlower(name) {
    let flower = {name: name};
    this.svc.createFlower(flower).subscribe(
       data => {
         // refresh the list
         this.getFlowers();
         return true;
       },
       error => {
         console.error("Error saving flower!");
         return Observable.throw(error);
       }
    );
  }

  updateFlower(flower) {
    this.svc.updateFood(flower).subscribe(
       data => {
         this.getFlowers();
         return true;
       },
       error => {
         console.error("Error saving Flower!");
         return Observable.throw(error);
       }
    );
  }

  deleteFlower(flower) {
    if (confirm("Are you sure you want to delete " + flower.name + "?")) {
      this.svc.deleteFood(flower).subscribe(
         data => {
           this.getFlowers();
           return true;
         },
         error => {
           console.error("Error deleting flower!");
           return Observable.throw(error);
         }
      );
    }
  }
}
