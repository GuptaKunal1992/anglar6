import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs/Observable';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class TransflowerService {
    constructor(private http:HttpClient) {   }

    getFlowers() {
        return this.http.get('/api/flowers');
    }

    getFruitsAndVegetables() {
        return Observable.forkJoin(
        this.http.get('/api/fruits'),
        this.http.get('/api/vegetables')
        );
    }

    createFlower(flower) {
        let body = JSON.stringify(flower);
        return this.http.post('/api/flowers/', body, httpOptions);
    }
   
    updateFood(flower) {
        let body = JSON.stringify(flower);
        return this.http.put('/api/flowers/' + flower.id, body, httpOptions);
    }

    deleteFood(flower) {
        return this.http.delete('/api/flowers/' + flower.id);
    }
}