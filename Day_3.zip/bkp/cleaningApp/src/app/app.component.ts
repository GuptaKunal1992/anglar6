import { Component } from '@angular/core';

@Component({
  selector: 'capp-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {}
