# CleaningApp

App is created as showcase of Progressive Wep Application capabilities in Angular framework.
App is intended for mobile browsers.

## Medium

https://medium.com/@vlado.tesanovic/the-prpl-pattern-for-progressive-web-applications-using-angular-6-f7237b7dc2a7

## Demo

https://cleaning-app-sjgglugavc.now.sh
