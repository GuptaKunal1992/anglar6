import { Component, OnInit } from '@angular/core';
import { ProductHubService } from '../productservice';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  private products:any[]
  constructor(private svc:ProductHubService) 
  {
     
   }

  ngOnInit() {
    this.products=this.svc.getProducts()
  }

}
