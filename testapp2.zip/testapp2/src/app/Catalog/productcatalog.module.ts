import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CounterComponent } from './counter/counter.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { ProductListComponent } from './product-list/product-list.component';
import {FormsModule} from '@angular/forms'
import { ProductHubService } from './productservice';
import { LifeCycleComponent, FlowerComponent } from './lifecycle';
import { CustomModule } from '../custom/custommodule';
import { SellingFlowersComponent } from './selling-flowers/selling-flowers.component';


@NgModule({
  declarations: [CounterComponent,ProductDetailComponent,ProductListComponent,LifeCycleComponent,FlowerComponent,SellingFlowersComponent],
  imports: [
    FormsModule,
    BrowserModule,
    CustomModule
  ],
  providers: [ProductHubService],
  exports:[CounterComponent,
  ProductDetailComponent,
  LifeCycleComponent,
ProductListComponent,
SellingFlowersComponent]
  
})
export class ProductCatalogModule { }
