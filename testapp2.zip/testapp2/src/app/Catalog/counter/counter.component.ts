import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-counter',
  templateUrl: './counter.component.html',
  styleUrls: ['./counter.component.css']
})
export class CounterComponent implements OnInit {

  @Output() update=new EventEmitter()
  @Input() count:number
  constructor() { 
    this.count=0;
  }

  ngOnInit() {
  }

  increment()
  {
    this.count++
    console.log("increment")
    this.update.emit({count:this.count})
  }
  decrement()
  {
    this.count--
    console.log("decrement")
    this.update.emit({count:this.count})
  }
}
