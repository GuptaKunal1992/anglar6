

export class Product{

    private id:Number;
    private title:string;
    private description:string;
    private price:Number;
    private quantity:Number;

    constructor(id,title,desc,price,quantity)
    {
        
    }

}