import { Injectable } from "@angular/core";

@Injectable()
export class ProductHubService
{
    constructor()
    {

    }

    getProducts():any
    {
        return [
            {id:34,title:"Gerbera",price:"45",description:"wedding flowers",likes:43,quantity:56},
            {id:4,title:"hisbuscus",price:"45",description:"wedding flowers",likes:53,quantity:56},
            {id:6,title:"Gabla",price:"45",description:"wedding flowers",likes:30,quantity:56},
            {id:56,title:"rose",price:"45",description:"wedding flowers",likes:3,quantity:56}
        ];
    }
}
