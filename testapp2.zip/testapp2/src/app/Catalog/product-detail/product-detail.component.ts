import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../product';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {

  @Input() name:string;
  @Input() price:number;
  @Input() quantity:number;
  @Input() ImageUrl:number;
  @Input() likes:number;

  constructor() {

  }

  ngOnInit() {
  }

  counterUpdate(event)
  {
    this.likes=event.count

  }

}
