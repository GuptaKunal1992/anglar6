import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'flower';
  flower={
    id:34,
    title:"Gebra",
    description:"wedding flower",
    quantity:45
  }
  isAvailable:boolean=false
  constructor()
  {
    console.log("debugger")
  }

}
