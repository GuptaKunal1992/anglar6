import { Component, OnInit } from '@angular/core';
import { FormGroup, AbstractControl, FormBuilder, Validators, FormControl } from '@angular/forms';

//Validation Policy 
function codeValidator(control: FormControl): { [s: string]: boolean } {
  if (!control.value.match(/^TFL/)) {
    return {invalidcode: true};
  }
}

//Validation Policy 
function numValidator(control: FormControl): { [s: string]: boolean } {
  if (control.value.length!=10) {
    return {invalidnum: true};
  }
}



@Component({
  selector: 'custom-validator',
  templateUrl: './product-custom-validator.component.html',
  styleUrls: ['./product-custom-validator.component.css']
})
export class ProductCustomValidatorComponent implements OnInit {
  ngOnInit() { }

  productForm: FormGroup;
  code: AbstractControl;
  mobile:AbstractControl;

  constructor(fb: FormBuilder) {
    this.productForm = fb.group({
      'code':  ['', Validators.compose([Validators.required, 
                                        codeValidator])],
      'mobile':  ['', Validators.compose([Validators.required, Validators.pattern('^(0|[1-9][0-9]*)$'),
                                          numValidator])]
    });

    this.code = this.productForm.controls['code'];
    this.mobile=this.productForm.controls['mobile']
  }

  onSubmit(value: string): void {
    console.log('you submitted value: ', value);
  }
}
