var tmp=5
tmp++;
console.log(tmp)
var sayHi=function(){
    console.log("welcom")
}
setInterval(sayHi,2000);
console.log("Terminating...")